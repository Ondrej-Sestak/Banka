﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace banka
{
    public class BeznyUcet
    {
        public string Nazevuctu { get; set; }
        public int Penize { get; set; }

        public BeznyUcet(string nazevuctu, int penize)
        {
            Nazevuctu = nazevuctu;
            Penize = penize;
        }

        // Přepsání ToString() pro lepší zobrazení v ListBoxu
        public override string ToString()
        {
            return $"Účet: {Nazevuctu}, Zůstatek: {Penize} Kč";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banka
{
    public partial class Form1 : Form
    {
        private List<BeznyUcet> listBeznychUctu = new List<BeznyUcet>();
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btprihlasit_Click(object sender, EventArgs e)
        {
            Uzivatel uzivatel = new Uzivatel(textBox1.Text, textBox2.Text);
            string uzivatelskejmeno = textBox1.Text;
            string heslo = textBox2.Text;

            if (uzivatelskejmeno != string.Empty && heslo != string.Empty)
            {
                if (uzivatel.Jmeno == uzivatelskejmeno && uzivatel.Heslo == heslo)
                {
                    Ucty ucty = new Ucty(listBeznychUctu);
                    ucty.Show();
                    MessageBox.Show("Byl jste úspěšně přihlášen");
                    


                }
                else if (heslo == "admin" && uzivatelskejmeno == "admin")
                {
                    Ucty ucty = new Ucty(listBeznychUctu);
                    ucty.Show();
                    MessageBox.Show("Byl jste úspěšně přihlášen");
                }
                else MessageBox.Show("Nesprávné údaje");
            }
            else MessageBox.Show("Zadejte správné hodnoty");
            
        }

        private void btvytvoritucet_Click(object sender, EventArgs e)
        {
            Vytvoritucet vytvoritucet = new Vytvoritucet();

            vytvoritucet.Show();
        }
    }
}

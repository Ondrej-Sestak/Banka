﻿namespace banka
{
    partial class Ucty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.účetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbuzivatel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbbezneucty = new System.Windows.Forms.ListBox();
            this.lbsporiciucty = new System.Windows.Forms.ListBox();
            this.btvytvorbezny = new System.Windows.Forms.Button();
            this.btposlatbezny = new System.Windows.Forms.Button();
            this.btposlatsporici = new System.Windows.Forms.Button();
            this.btvytvorsporici = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.účetToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(441, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // účetToolStripMenuItem
            // 
            this.účetToolStripMenuItem.Name = "účetToolStripMenuItem";
            this.účetToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.účetToolStripMenuItem.Text = "Účet";
            // 
            // lbuzivatel
            // 
            this.lbuzivatel.AutoSize = true;
            this.lbuzivatel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbuzivatel.Location = new System.Drawing.Point(156, 24);
            this.lbuzivatel.Name = "lbuzivatel";
            this.lbuzivatel.Size = new System.Drawing.Size(73, 20);
            this.lbuzivatel.TabIndex = 1;
            this.lbuzivatel.Text = "Uživatel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Běžné účty";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Spořící účty";
            // 
            // lbbezneucty
            // 
            this.lbbezneucty.FormattingEnabled = true;
            this.lbbezneucty.Location = new System.Drawing.Point(32, 86);
            this.lbbezneucty.Name = "lbbezneucty";
            this.lbbezneucty.Size = new System.Drawing.Size(120, 199);
            this.lbbezneucty.TabIndex = 4;
            // 
            // lbsporiciucty
            // 
            this.lbsporiciucty.FormattingEnabled = true;
            this.lbsporiciucty.Location = new System.Drawing.Point(263, 86);
            this.lbsporiciucty.Name = "lbsporiciucty";
            this.lbsporiciucty.Size = new System.Drawing.Size(120, 199);
            this.lbsporiciucty.TabIndex = 5;
            // 
            // btvytvorbezny
            // 
            this.btvytvorbezny.Location = new System.Drawing.Point(50, 291);
            this.btvytvorbezny.Name = "btvytvorbezny";
            this.btvytvorbezny.Size = new System.Drawing.Size(83, 23);
            this.btvytvorbezny.TabIndex = 6;
            this.btvytvorbezny.Text = "Vytvořit účet";
            this.btvytvorbezny.UseVisualStyleBackColor = true;
            this.btvytvorbezny.Click += new System.EventHandler(this.btvytvorbezny_Click);
            // 
            // btposlatbezny
            // 
            this.btposlatbezny.Location = new System.Drawing.Point(50, 320);
            this.btposlatbezny.Name = "btposlatbezny";
            this.btposlatbezny.Size = new System.Drawing.Size(83, 23);
            this.btposlatbezny.TabIndex = 7;
            this.btposlatbezny.Text = "Poslat peníze";
            this.btposlatbezny.UseVisualStyleBackColor = true;
            this.btposlatbezny.Click += new System.EventHandler(this.btposlatbezny_Click);
            // 
            // btposlatsporici
            // 
            this.btposlatsporici.Location = new System.Drawing.Point(284, 320);
            this.btposlatsporici.Name = "btposlatsporici";
            this.btposlatsporici.Size = new System.Drawing.Size(83, 23);
            this.btposlatsporici.TabIndex = 9;
            this.btposlatsporici.Text = "Poslat peníze";
            this.btposlatsporici.UseVisualStyleBackColor = true;
            this.btposlatsporici.Click += new System.EventHandler(this.btposlatsporici_Click);
            // 
            // btvytvorsporici
            // 
            this.btvytvorsporici.Location = new System.Drawing.Point(284, 291);
            this.btvytvorsporici.Name = "btvytvorsporici";
            this.btvytvorsporici.Size = new System.Drawing.Size(83, 23);
            this.btvytvorsporici.TabIndex = 8;
            this.btvytvorsporici.Text = "Vytvořit účet";
            this.btvytvorsporici.UseVisualStyleBackColor = true;
            this.btvytvorsporici.Click += new System.EventHandler(this.btvytvorsporici_Click);
            // 
            // Ucty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 450);
            this.Controls.Add(this.btposlatsporici);
            this.Controls.Add(this.btvytvorsporici);
            this.Controls.Add(this.btposlatbezny);
            this.Controls.Add(this.btvytvorbezny);
            this.Controls.Add(this.lbsporiciucty);
            this.Controls.Add(this.lbbezneucty);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbuzivatel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Ucty";
            this.Text = "Ucty";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem účetToolStripMenuItem;
        private System.Windows.Forms.Label lbuzivatel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbbezneucty;
        private System.Windows.Forms.ListBox lbsporiciucty;
        private System.Windows.Forms.Button btvytvorbezny;
        private System.Windows.Forms.Button btposlatbezny;
        private System.Windows.Forms.Button btposlatsporici;
        private System.Windows.Forms.Button btvytvorsporici;
    }
}
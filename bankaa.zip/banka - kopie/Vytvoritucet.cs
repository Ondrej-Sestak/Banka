﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banka
{
    public partial class Vytvoritucet : Form
    {
        public Vytvoritucet()
        {
            InitializeComponent();
        }

        private void btvytvorit_Click(object sender, EventArgs e)
        {
            if (tbjmeno.Text != string.Empty && tbheslo.Text != string.Empty && tbhesloznovu.Text != string.Empty)
            {
                if (tbheslo.Text == tbhesloznovu.Text)
                {
                    Class1.listUzivatelu.Add(new Uzivatel(tbjmeno.Text, tbheslo.Text));
                    MessageBox.Show("Účet uživatele byl založen.");

                }
                else
                    MessageBox.Show("Heslo není stejné");
            }
        }
    }
}

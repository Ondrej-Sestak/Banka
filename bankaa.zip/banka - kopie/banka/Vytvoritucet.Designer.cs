﻿namespace banka
{
    partial class Vytvoritucet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbjmeno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbheslo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbhesloznovu = new System.Windows.Forms.TextBox();
            this.btvytvorit = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btzpatky = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vytvořit Uživatele";
            // 
            // tbjmeno
            // 
            this.tbjmeno.Location = new System.Drawing.Point(44, 64);
            this.tbjmeno.Name = "tbjmeno";
            this.tbjmeno.Size = new System.Drawing.Size(126, 20);
            this.tbjmeno.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Přihlašovací jméno";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Heslo";
            // 
            // tbheslo
            // 
            this.tbheslo.Location = new System.Drawing.Point(44, 118);
            this.tbheslo.Name = "tbheslo";
            this.tbheslo.Size = new System.Drawing.Size(126, 20);
            this.tbheslo.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Potvrďte heslo";
            // 
            // tbhesloznovu
            // 
            this.tbhesloznovu.Location = new System.Drawing.Point(44, 172);
            this.tbhesloznovu.Name = "tbhesloznovu";
            this.tbhesloznovu.Size = new System.Drawing.Size(126, 20);
            this.tbhesloznovu.TabIndex = 7;
            // 
            // btvytvorit
            // 
            this.btvytvorit.Location = new System.Drawing.Point(44, 223);
            this.btvytvorit.Name = "btvytvorit";
            this.btvytvorit.Size = new System.Drawing.Size(126, 25);
            this.btvytvorit.TabIndex = 9;
            this.btvytvorit.Text = "VYTVOŘIT";
            this.btvytvorit.UseVisualStyleBackColor = true;
            this.btvytvorit.Click += new System.EventHandler(this.btvytvorit_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(82, 198);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(88, 17);
            this.checkBox1.TabIndex = 10;
            this.checkBox1.Text = "Ukázat heslo";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btzpatky
            // 
            this.btzpatky.Location = new System.Drawing.Point(44, 254);
            this.btzpatky.Name = "btzpatky";
            this.btzpatky.Size = new System.Drawing.Size(126, 25);
            this.btzpatky.TabIndex = 11;
            this.btzpatky.Text = "ZPÁTKY";
            this.btzpatky.UseVisualStyleBackColor = true;
            // 
            // Vytvoritucet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(227, 317);
            this.Controls.Add(this.btzpatky);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btvytvorit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbhesloznovu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbheslo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbjmeno);
            this.Controls.Add(this.label1);
            this.Name = "Vytvoritucet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vytvoritucet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbjmeno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbheslo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbhesloznovu;
        private System.Windows.Forms.Button btvytvorit;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btzpatky;
    }
}
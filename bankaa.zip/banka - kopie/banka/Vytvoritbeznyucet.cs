﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace banka
{
    public partial class Vytvoritbeznyucet : Form
    {
        private BeznyUcet beznyucet;
        private List<BeznyUcet> listBeznychUctu;

        public Vytvoritbeznyucet()
        {
            InitializeComponent();
            listBeznychUctu = new List<BeznyUcet>(); 
        }

        private void btvytvoritbeznyucet_Click(object sender, EventArgs e)
        {
            if (tbmajitel != null & tbvytvoritbeznyucet.Text != null & nuppenize != null)
            {
                beznyucet = new BeznyUcet(tbvytvoritbeznyucet.Text, Convert.ToInt32(nuppenize.Value), tbmajitel.Text);
                listBeznychUctu.Add(beznyucet);

                Ucty ucty = new Ucty(listBeznychUctu);
                ucty.Show();

                MessageBox.Show("Běžný účet byl vytvořen");
            }
            else
                MessageBox.Show("Vyplňtě všechny pole");
        }
    }
}

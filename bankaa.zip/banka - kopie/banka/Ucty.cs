﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banka
{
    public partial class Ucty : Form
    {
        public Ucty(List<BeznyUcet> bezneUcty)
        {
            InitializeComponent();

            foreach (var ucet in bezneUcty)
            {
                lbbezneucty.Items.Add(ucet); 
            }
        }

        private void btvytvorbezny_Click(object sender, EventArgs e)
        {
            Vytvoritbeznyucet vytvoritbeznyucet = new Vytvoritbeznyucet();
            vytvoritbeznyucet.Show();
        }

        private void btposlatbezny_Click(object sender, EventArgs e)
        {
           
        }

        private void btvytvorsporici_Click(object sender, EventArgs e)
        {
            VytvoreniSporiciUcet vytvorenisporiciucet = new VytvoreniSporiciUcet();
            vytvorenisporiciucet.Show();
        }

        private void btposlatsporici_Click(object sender, EventArgs e)
        {
            
        }
    }
}

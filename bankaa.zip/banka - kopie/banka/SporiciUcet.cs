﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace banka
{
    class SporiciUcet
    {
        public string Nazevuctu { get; set; }
        public int Penize { get; set; }

        public string Vlastnik { get; set; }
        public SporiciUcet(string nazevuctu, int penize, string vlastnik)
        {
            Nazevuctu = nazevuctu;
            Penize = penize;
            Vlastnik = vlastnik;
        }
        public override string ToString()
        {
            return $"Účet: {Nazevuctu}, Zůstatek: {Penize} Kč, Majitel: {Vlastnik}";
        }


    }
}

﻿namespace banka
{
    partial class Vytvoritbeznyucet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbvytvoritbeznyucet = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nuppenize = new System.Windows.Forms.NumericUpDown();
            this.btvytvoritbeznyucet = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tbmajitel = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nuppenize)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(56, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "BĚŽNÝ ÚČET";
            // 
            // tbvytvoritbeznyucet
            // 
            this.tbvytvoritbeznyucet.Location = new System.Drawing.Point(60, 79);
            this.tbvytvoritbeznyucet.Name = "tbvytvoritbeznyucet";
            this.tbvytvoritbeznyucet.Size = new System.Drawing.Size(148, 20);
            this.tbvytvoritbeznyucet.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(90, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Název účtu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(75, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Peníze na účtě";
            // 
            // nuppenize
            // 
            this.nuppenize.Location = new System.Drawing.Point(60, 166);
            this.nuppenize.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nuppenize.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nuppenize.Name = "nuppenize";
            this.nuppenize.Size = new System.Drawing.Size(148, 20);
            this.nuppenize.TabIndex = 5;
            this.nuppenize.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // btvytvoritbeznyucet
            // 
            this.btvytvoritbeznyucet.Location = new System.Drawing.Point(88, 205);
            this.btvytvoritbeznyucet.Name = "btvytvoritbeznyucet";
            this.btvytvoritbeznyucet.Size = new System.Drawing.Size(75, 23);
            this.btvytvoritbeznyucet.TabIndex = 6;
            this.btvytvoritbeznyucet.Text = "Vytvořit";
            this.btvytvoritbeznyucet.UseVisualStyleBackColor = true;
            this.btvytvoritbeznyucet.Click += new System.EventHandler(this.btvytvoritbeznyucet_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(104, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Majitel";
            // 
            // tbmajitel
            // 
            this.tbmajitel.Location = new System.Drawing.Point(60, 124);
            this.tbmajitel.Name = "tbmajitel";
            this.tbmajitel.Size = new System.Drawing.Size(148, 20);
            this.tbmajitel.TabIndex = 7;
            // 
            // Vytvoritbeznyucet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 260);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbmajitel);
            this.Controls.Add(this.btvytvoritbeznyucet);
            this.Controls.Add(this.nuppenize);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbvytvoritbeznyucet);
            this.Controls.Add(this.label1);
            this.Name = "Vytvoritbeznyucet";
            this.Text = "Vytvoritbeznyucet";
            ((System.ComponentModel.ISupportInitialize)(this.nuppenize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbvytvoritbeznyucet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nuppenize;
        private System.Windows.Forms.Button btvytvoritbeznyucet;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbmajitel;
    }
}
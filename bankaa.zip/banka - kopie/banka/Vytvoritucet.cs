﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlTypes;

namespace banka
{
    public partial class Vytvoritucet : Form
    {
        public Vytvoritucet()
        {
            InitializeComponent();
        }

        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=db_users.mdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter da = new OleDbDataAdapter();

        private void btvytvorit_Click(object sender, EventArgs e)
        {
            if (tbheslo.Text == "" && tbjmeno.Text == "" && tbhesloznovu.Text == "")
            {
                MessageBox.Show("Vyplňte všechny pole prosím");
            }
            else if (tbheslo.Text == tbhesloznovu.Text)
            {
                con.Open();
                string register = "INSERT INTO db_users (jmeno, heslo) VALUES (?, ?)";
                cmd = new OleDbCommand(register, con);
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Váš účet byl vytvořený");
            }
            else
                MessageBox.Show("Hesla se neshodují");
            tbheslo.Text = "";
            tbhesloznovu.Text = "";
            tbheslo.Focus();
        }
    }
}

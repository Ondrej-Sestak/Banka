﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banka
{
    public partial class VytvoreniSporiciUcet : Form
    {
        public VytvoreniSporiciUcet()
        {
            InitializeComponent();
        }

        private void btvytvoritsporiciucet_Click(object sender, EventArgs e)
        {   if (tbmajitelsporiciucet.Text != "" & tbvytvoritsporiciucet.Text != "")
            {
                List<SporiciUcet> sporiciucty = new List<SporiciUcet>();
                sporiciucty.Add(new SporiciUcet(tbvytvoritsporiciucet.Text, Convert.ToInt32(nuppenizesporiciucet.Value), tbmajitelsporiciucet.Text));
                Form ucty = new Form(); 
                ucty.Show();
            }
            else
                MessageBox.Show("Vyplňte prosím všechna pole");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace banka
{
    internal class Class1
    {
        public static List<Uzivatel> listUzivatelu = new List<Uzivatel>();
        public static List<BeznyUcet> listBeznychUctu = new List<BeznyUcet>();
        public static List<SporiciUcet> listSporicichUctu = new List<SporiciUcet>();
    
    }
}

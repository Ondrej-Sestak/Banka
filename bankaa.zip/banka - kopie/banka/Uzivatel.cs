﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace banka
{
    class Uzivatel
    {
        public string Jmeno { get; set; }
        public string Heslo { get; set; }
        public Uzivatel(string jmeno, string heslo)
        {
            Jmeno = jmeno;
            Heslo = heslo;
        }
        public Uzivatel(int jmeno, int heslo)
        {
            Jmeno = jmeno.ToString();
            Heslo = heslo.ToString();
        }
        public Uzivatel(string radek)
        {
            string[] rozdeleni = radek.Split(';');
            Jmeno = rozdeleni[0];
            Heslo = rozdeleni[1];
        }
        public string ToCSV()
        {
            return $"{Jmeno};{Heslo}";
        }
        public override string ToString()
        {
            return $"Uživatel: {Jmeno}, Heslo: {Heslo}";
        }
    }
}


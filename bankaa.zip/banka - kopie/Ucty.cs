﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banka
{
    public partial class Ucty : Form
    {
        public Ucty(List<BeznyUcet> bezneUcty)
        {
            InitializeComponent();

            label3.Visible = false;
            lbsporiciucty.Visible = false;
            btvytvorsporici.Visible = false;
            btposlatsporici.Visible = false;

            
            foreach (var ucet in bezneUcty)
            {
                lbbezneucty.Items.Add(ucet.ToString());
            }
        }

        private void btvytvorbezny_Click(object sender, EventArgs e)
        {
            Vytvoritbeznyucet vytvoritbeznyucet = new Vytvoritbeznyucet();

            vytvoritbeznyucet.Show();
            label3.Visible = true;
            lbsporiciucty.Visible = true;
            btvytvorsporici.Visible = true;
            btposlatsporici.Visible = true;
        }

        private void btposlatbezny_Click(object sender, EventArgs e)
        {

        }

        private void btvytvorsporici_Click(object sender, EventArgs e)
        {

        }

        private void btposlatsporici_Click(object sender, EventArgs e)
        {

        }
    }
}

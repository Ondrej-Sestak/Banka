﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace banka
{
    public partial class Vytvoritbeznyucet : Form
    {
        // Seznam běžných účtů
        public static List<BeznyUcet> listBeznychUctu = new List<BeznyUcet>();

        public Vytvoritbeznyucet()
        {
            InitializeComponent();
        }

        // Tlačítko pro vytvoření běžného účtu
        private void btvytvoritbeznyucet_Click(object sender, EventArgs e)
        {
            // Vytvoření nového běžného účtu
            BeznyUcet beznyucet = new BeznyUcet(tbvytvoritbeznyucet.Text, Convert.ToInt32(nuppenize.Value));

            // Přidání účtu do seznamu běžných účtů
            listBeznychUctu.Add(beznyucet);

            // Otevření formuláře Ucty s předáním seznamu běžných účtů
            Ucty ucty = new Ucty(listBeznychUctu);
            ucty.Show();
            MessageBox.Show("Běžný účet byl vytvořen");
        }
    }
}
